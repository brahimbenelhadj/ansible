# Snippets
Pour installer ces snippets (squelettes des tempaltes Wazi deploy), voici la démarche :

1) cloner le repo GIT snippets contenant ces snippets dans votre répertoire local :

        C:\Users\userid\AppData\Roaming\Code\User

Adresse du repo : https://gitlab-dogen.group.echonet/market-place/ap26473/mdp/prod/snippets.git

Il faudra saisir ce répertoire lorqsue que VSCODE vous demande où installer ce repo !

==> Cela vous permet de les mettre à jour en faisant un pull depuis VSCODE pour instalelr une bnouvelle version de ces snippets.

La snippet Template vous permet d'avoir la liste de templates wazi Deploy disponibles et le mode d'utilisation des snippets.

Si souci ou pour les retrouver sur votre poste, il faut activer les dossiers/ficheirs cachés sous Windows
Pour cela, sous Explorer, sélectionner affichage, puis options (à droite) puis affichage dans la boite de dialogue
et enfin cocher Afficher les fichiers, dossiers et lecteurs cachés.